class User {
  final String id;
  final String name;
  final String email;
  final String field;
  final String university;
  final String? profileImageUrl;
  final List<String> interests;
  final Map<String, dynamic>? stats;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.field,
    required this.university,
    this.profileImageUrl,
    required this.interests,
    this.stats,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      field: json['field'] ?? '',
      university: json['university'] ?? '',
      profileImageUrl: json['profileImageUrl'],
      interests: List<String>.from(json['interests'] ?? []),
      stats: json['stats'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'field': field,
      'university': university,
      'profileImageUrl': profileImageUrl,
      'interests': interests,
      'stats': stats,
    };
  }

  User copyWith({
    String? id,
    String? name,
    String? email,
    String? field,
    String? university,
    String? profileImageUrl,
    List<String>? interests,
    Map<String, dynamic>? stats,
  }) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      field: field ?? this.field,
      university: university ?? this.university,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      interests: interests ?? this.interests,
      stats: stats ?? this.stats,
    );
  }
}
