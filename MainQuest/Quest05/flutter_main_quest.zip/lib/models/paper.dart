class Paper {
  final String id;
  final String title;
  final List<String> authors;
  final String journal;
  final String? doi;
  final String? abstract;
  final int year;
  final int? citationCount;
  final double? avgRating;
  final List<String>? keywords;
  final String? pdfUrl;

  Paper({
    required this.id,
    required this.title,
    required this.authors,
    required this.journal,
    this.doi,
    this.abstract,
    required this.year,
    this.citationCount,
    this.avgRating,
    this.keywords,
    this.pdfUrl,
  });

  factory Paper.fromJson(Map<String, dynamic> json) {
    return Paper(
      id: json['id'],
      title: json['title'],
      authors: List<String>.from(json['authors']),
      journal: json['journal'],
      doi: json['doi'],
      abstract: json['abstract'],
      year: json['year'],
      citationCount: json['citationCount'],
      avgRating: json['avgRating']?.toDouble(),
      keywords:
          json['keywords'] != null ? List<String>.from(json['keywords']) : null,
      pdfUrl: json['pdfUrl'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'authors': authors,
      'journal': journal,
      'doi': doi,
      'abstract': abstract,
      'year': year,
      'citationCount': citationCount,
      'avgRating': avgRating,
      'keywords': keywords,
      'pdfUrl': pdfUrl,
    };
  }
}

class PaperRating {
  final String id;
  final String paperId;
  final String userId;
  final String? userName;
  final double rating;
  final String? comment;
  final DateTime createdAt;

  PaperRating({
    required this.id,
    required this.paperId,
    required this.userId,
    this.userName,
    required this.rating,
    this.comment,
    required this.createdAt,
  });

  factory PaperRating.fromJson(Map<String, dynamic> json) {
    return PaperRating(
      id: json['id'],
      paperId: json['paperId'],
      userId: json['userId'],
      userName: json['userName'],
      rating: json['rating'].toDouble(),
      comment: json['comment'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'paperId': paperId,
      'userId': userId,
      'userName': userName,
      'rating': rating,
      'comment': comment,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}
