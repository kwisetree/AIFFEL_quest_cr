import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/edit_profile_screen.dart';
import 'dart:async';
import 'package:universal_html/html.dart' as html;
import 'package:flutter_web_plugins/flutter_web_plugins.dart';
import 'dart:ui' as ui;
import 'providers/user_profile_provider.dart';

void main() {
  // HTML 요소 등록
  // ignore: undefined_prefixed_name
  ui.platformViewRegistry.registerViewFactory(
    'camera-container',
    (int viewId) {
      final div = html.DivElement()
        ..id = 'camera-container'
        ..style.width = '100%'
        ..style.height = '100%';
      return div;
    },
  );

  runApp(
    ChangeNotifierProvider(
      create: (context) => UserProfileProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => UserProfileProvider(),
      child: MaterialApp(
        title: 'SOCIOpedia',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: const Color(0xFF4C9F8C), // 자연적인 청록색
          colorScheme: ColorScheme.light(
            primary: const Color(0xFF4C9F8C), // 청록색
            secondary: const Color(0xFF80C1B0), // 밝은 청록색
            surface: Colors.white,
            background: const Color(0xFFF8F9FA), // 약간의 배경색 추가
            onPrimary: Colors.white,
            onSecondary: Colors.black87,
            onSurface: Colors.black,
            onBackground: Colors.black,
          ),
          scaffoldBackgroundColor: const Color(0xFFF8F9FA),
          cardColor: Colors.white,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black87,
            elevation: 0.5, // 약간의 입체감
            centerTitle: true,
            titleTextStyle: TextStyle(
              color: Colors.black87,
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
            iconTheme: IconThemeData(
              color: Colors.black87,
            ),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF4C9F8C),
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
          ),
        ),
        home: const SplashScreen(),
      ),
    );
  }
}

// 스플래시 화면
class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeInAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _fadeInAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
      ),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutBack),
      ),
    );

    _controller.forward();

    // 3초 후 메인 화면으로 이동
    Timer(
      const Duration(seconds: 3),
      () => Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 800),
          pageBuilder: (context, animation, secondaryAnimation) =>
              const MainScreen(),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return FadeTransition(
              opacity: animation,
              child: child,
            );
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 애니메이션 로고
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return Opacity(
                  opacity: _fadeInAnimation.value,
                  child: Transform.scale(
                    scale: _scaleAnimation.value,
                    child: child,
                  ),
                );
              },
              child: Container(
                width: 250,
                height: 150,
                decoration: BoxDecoration(
                  color: const Color(0xFFE6F3F0), // 연한 청록색
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF4C9F8C).withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Center(
                  child: Image.asset(
                    'assets/images/SOCIOpedia.PNG',
                    width: 220,
                    height: 130,
                    errorBuilder: (context, error, stackTrace) {
                      print('이미지 로드 실패: $error');
                      // 이미지 로드 실패 시 대체 UI
                      return const Text(
                        'SOCIOpedia',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF4C9F8C),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(height: 40),
            // 로딩 인디케이터
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0.0, end: 1.0),
              duration: const Duration(seconds: 3),
              builder: (context, value, child) {
                return SizedBox(
                  width: 50,
                  height: 50,
                  child: CircularProgressIndicator(
                    value: value,
                    color: const Color(0xFF4C9F8C),
                    strokeWidth: 5,
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            FadeTransition(
              opacity: _fadeInAnimation,
              child: const Text(
                '당신의 학술 여정을 시작합니다',
                style: TextStyle(
                  color: Color(0xFF4C9F8C),
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 메인 스크린 (하단 네비게이션 바 포함)
class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  // 네비게이션 바에 표시할 화면들
  final List<Widget> _screens = const [
    DashboardScreen(), // 홈
    SearchScreen(), // 검색
    FavoritesScreen(), // 찜
    NotificationsScreen(), // 소식
    ProfileScreen(), // 나의 SOC
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 10,
              spreadRadius: 0,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(25),
              child: BottomNavigationBar(
                type: BottomNavigationBarType.fixed,
                currentIndex: _selectedIndex,
                onTap: (index) {
                  setState(() {
                    _selectedIndex = index;
                  });
                },
                selectedItemColor: const Color(0xFF4C9F8C),
                unselectedItemColor: Colors.black54,
                backgroundColor: Colors.white,
                elevation: 0,
                showSelectedLabels: true,
                showUnselectedLabels: true,
                selectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                ),
                unselectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 11,
                ),
                items: [
                  _buildNavItem(Icons.home_outlined, Icons.home, '홈'),
                  _buildNavItem(Icons.search_outlined, Icons.search, '검색'),
                  _buildNavItem(Icons.star_outline, Icons.star, '찜'),
                  _buildNavItem(
                      Icons.notifications_outlined, Icons.notifications, '소식'),
                  _buildNavItem(Icons.person_outline, Icons.person, '나의 SOC'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  BottomNavigationBarItem _buildNavItem(
      IconData unselectedIcon, IconData selectedIcon, String label) {
    return BottomNavigationBarItem(
      icon: Icon(unselectedIcon),
      activeIcon: Icon(selectedIcon),
      label: label,
    );
  }
}

// 홈 화면 (DashboardScreen)
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset(
          'assets/images/SOCIOpedia.PNG',
          height: 30,
          errorBuilder: (context, error, stackTrace) {
            print('이미지 로드 실패: $error');
            return const Text(
              'SOCIOpedia',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: RefreshIndicator(
        color: const Color(0xFF4C9F8C),
        onRefresh: () async {
          // 새로고침 로직
          await Future.delayed(const Duration(seconds: 1));
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 프로필 카드
                _buildProfileCard(),
                const SizedBox(height: 24),

                // 통계 요약 카드
                _buildStatsCard(),
                const SizedBox(height: 24),

                // 최근 활동 섹션
                _buildRecentActivitySection(),
                const SizedBox(height: 24),

                // 보관함 섹션
                _buildArchiveSection(),
                const SizedBox(height: 24),

                // 캘린더 섹션
                _buildCalendarSection(),
                const SizedBox(height: 20),

                // 추천 논문 섹션
                _buildRecommendedPapersSection(),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 논문 검색 또는 추가 페이지로 이동
          _showAddPaperDialog();
        },
        backgroundColor: const Color(0xFF4C9F8C),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  // 프로필 카드 위젯
  // 프로필 카드 위젯
  Widget _buildProfileCard() {
    return Consumer<UserProfileProvider>(
        builder: (context, userProfile, child) {
      return Card(
        elevation: 2,
        shadowColor: Colors.black12,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: const Color(0xFF4C9F8C),
                    backgroundImage: userProfile.imageFile != null
                        ? MemoryImage(userProfile.imageFile!)
                        : null,
                    child: userProfile.imageFile == null
                        ? Text(
                            userProfile.name.isNotEmpty
                                ? userProfile.name.substring(0, 1)
                                : '사',
                            style: const TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          )
                        : null,
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white,
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.verified,
                        size: 14,
                        color: Color(0xFF4C9F8C),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      userProfile.name,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(
                          Icons.school,
                          size: 14,
                          color: Color(0xFF4C9F8C),
                        ),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            '연구 분야: ${userProfile.field}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(
                          Icons.location_on,
                          size: 14,
                          color: Color(0xFF4C9F8C),
                        ),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            userProfile.university,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 36,
                child: OutlinedButton(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const EditProfileScreen()),
                    );

                    if (result == true) {
                      // 프로필 수정 완료 후 데이터 새로고침
                      Provider.of<UserProfileProvider>(context, listen: false)
                          .loadProfileData();
                    }
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF4C9F8C),
                    side: const BorderSide(color: Color(0xFF4C9F8C)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 0,
                    ),
                  ),
                  child: const Text(
                    '수정',
                    style: TextStyle(fontSize: 13),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  // 통계 요약 카드 위젯
  Widget _buildStatsCard() {
    return Card(
      elevation: 2,
      shadowColor: Colors.black12,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStatItem('635', '평가', Icons.rate_review_outlined),
            Container(
              height: 40,
              width: 1,
              color: Colors.grey[300],
            ),
            _buildStatItem('0', '코멘트', Icons.comment_outlined),
            Container(
              height: 40,
              width: 1,
              color: Colors.grey[300],
            ),
            _buildStatItem('0', '컬렉션', Icons.collections_bookmark_outlined),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String value, String label, IconData icon) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF4C9F8C),
          ),
        ),
        const SizedBox(height: 4),
        Row(
          children: [
            Icon(
              icon,
              size: 14,
              color: Colors.grey[600],
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[700],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // 최근 활동 섹션 위젯
  Widget _buildRecentActivitySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Row(
              children: [
                Text(
                  '최근 활동',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(width: 8),
                Icon(Icons.history, color: Color(0xFF4C9F8C), size: 18),
              ],
            ),
            TextButton(
              onPressed: () {},
              child: const Text(
                '모두 보기',
                style: TextStyle(
                  color: Color(0xFF4C9F8C),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 80,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 5,
            itemBuilder: (context, index) {
              return Container(
                width: 190,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      blurRadius: 4,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE6F3F0),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Icon(
                              Icons.star,
                              color: Color(0xFF4C9F8C),
                              size: 14,
                            ),
                          ),
                          const SizedBox(width: 6),
                          const Text(
                            '논문 평가',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '사회 네트워크 분석 논문 ${index + 1}',
                        style: const TextStyle(
                          fontSize: 12,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        '${DateTime.now().hour - index}시간 전',
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // 보관함 섹션 위젯
  Widget _buildArchiveSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Text(
              '보관함',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(width: 8),
            Icon(Icons.bookmark, color: Color(0xFF4C9F8C), size: 18),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildArchiveItem('논문', Icons.article, '635'),
            _buildArchiveItem('책', Icons.book, '24'),
            _buildArchiveItem('연구자', Icons.person, '12'),
            _buildArchiveItem('학술지', Icons.library_books, '5'),
          ],
        ),
      ],
    );
  }

  Widget _buildArchiveItem(String label, IconData icon, String count) {
    return InkWell(
      onTap: () {
        // 각 보관함 항목 탭 시 해당 카테고리 페이지로 이동
      },
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  color: const Color(0xFFE6F3F0),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      blurRadius: 4,
                      spreadRadius: 1,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Icon(
                  icon,
                  size: 32,
                  color: const Color(0xFF4C9F8C),
                ),
              ),
              if (count != '0')
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Color(0xFF4C9F8C),
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      count,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  // 캘린더 섹션 위젯
  Widget _buildCalendarSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Row(
              children: [
                Text(
                  '캘린더',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(width: 8),
                Icon(Icons.calendar_today, color: Color(0xFF4C9F8C), size: 18),
              ],
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFE6F3F0),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF4C9F8C), width: 1),
              ),
              child: Text(
                '${_focusedDay.year}.${_focusedDay.month}',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey[800],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Card(
          elevation: 2,
          shadowColor: Colors.black12,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: Icon(Icons.chevron_left, color: Colors.grey[600]),
                      onPressed: () {
                        setState(() {
                          _focusedDay = DateTime(
                              _focusedDay.year, _focusedDay.month - 1, 1);
                        });
                      },
                    ),
                    Text(
                      '${_focusedDay.year}년 ${_focusedDay.month}월',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.chevron_right, color: Colors.grey[600]),
                      onPressed: () {
                        setState(() {
                          _focusedDay = DateTime(
                              _focusedDay.year, _focusedDay.month + 1, 1);
                        });
                      },
                    ),
                  ],
                ),
                // 간단한 캘린더 UI
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 7,
                    childAspectRatio: 1.0,
                  ),
                  itemCount: 37, // 요일 7개 + 30일
                  itemBuilder: (context, index) {
                    if (index < 7) {
                      // 요일 행 (일~토)
                      final days = ['일', '월', '화', '수', '목', '금', '토'];
                      return Center(
                        child: Text(
                          days[index],
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: index == 0
                                ? Colors.red[300]
                                : (index == 6
                                    ? Colors.blue[300]
                                    : Colors.black87),
                          ),
                        ),
                      );
                    } else {
                      // 날짜 cell
                      final dayNum = index - 6;
                      final isToday = dayNum == DateTime.now().day &&
                          _focusedDay.month == DateTime.now().month &&
                          _focusedDay.year == DateTime.now().year;
                      final hasActivity = [3, 8, 12, 17, 25].contains(dayNum);

                      if (dayNum > 31) return const SizedBox.shrink();

                      return GestureDetector(
                        onTap: () {
                          // 날짜 선택 로직
                          setState(() {
                            _selectedDay = DateTime(
                                _focusedDay.year, _focusedDay.month, dayNum);
                          });

                          if (hasActivity) {
                            _showDayActivitiesDialog(dayNum);
                          }
                        },
                        child: Container(
                          margin: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: isToday
                                ? const Color(0xFF4C9F8C)
                                : (_selectedDay?.day == dayNum &&
                                        _selectedDay?.month ==
                                            _focusedDay.month &&
                                        _selectedDay?.year == _focusedDay.year)
                                    ? const Color(0xFFB3E0D5)
                                    : (hasActivity
                                        ? const Color(0xFFE6F3F0)
                                        : Colors.transparent),
                            shape: BoxShape.circle,
                          ),
                          child: Center(
                            child: Text(
                              dayNum.toString(),
                              style: TextStyle(
                                color: isToday ? Colors.white : Colors.black87,
                                fontWeight: hasActivity || isToday
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                              ),
                            ),
                          ),
                        ),
                      );
                    }
                  },
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        color: Color(0xFF4C9F8C),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Text('오늘'),
                    const SizedBox(width: 16),
                    Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        color: Color(0xFFE6F3F0),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Text('활동 있음'),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // 추천 논문 섹션 위젯
  Widget _buildRecommendedPapersSection() {
    final List<String> papers = [
      '사회적 연결망 분석과 현대 사회학',
      '디지털 시대의 사회 관계 연구',
      '집단 행동 이론과 응용',
      '문화 이론의 새로운 패러다임',
      '사회심리학의 최신 동향'
    ];

    final List<String> authors = [
      '김수현, 이태호',
      '박지영, 최민준',
      '정민석',
      '한지원, 이승호, 강유진',
      '윤서연, 장민우'
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Row(
              children: [
                Text(
                  '추천 논문',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(width: 8),
                Icon(Icons.recommend, color: Color(0xFF4C9F8C), size: 18),
              ],
            ),
            TextButton(
              onPressed: () {},
              child: const Text(
                '더 보기',
                style: TextStyle(
                  color: Color(0xFF4C9F8C),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 235,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 5,
            itemBuilder: (context, index) {
              return Container(
                width: 170,
                margin: const EdgeInsets.only(right: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      blurRadius: 5,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 95,
                      decoration: BoxDecoration(
                        color: const Color(0xFFE6F3F0),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(12),
                          topRight: Radius.circular(12),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF4C9F8C).withOpacity(0.1),
                            blurRadius: 3,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Icon(
                          Icons.article,
                          size: 40,
                          color: const Color(0xFF4C9F8C).withOpacity(0.8),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            papers[index],
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            authors[index],
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey[700],
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '2024년 ${index + 1}월',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey[700],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                    size: 14,
                                  ),
                                  const SizedBox(width: 2),
                                  Text(
                                    '${(4 + index % 2) / 2 + 3}',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              InkWell(
                                onTap: () {},
                                child: const Icon(
                                  Icons.bookmark_outline,
                                  color: Color(0xFF4C9F8C),
                                  size: 18,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // 논문 추가 다이얼로그
  void _showAddPaperDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: const Text('논문 추가'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('어떤 방식으로 논문을 추가하시겠습니까?'),
              const SizedBox(height: 20),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE6F3F0),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.search, color: Color(0xFF4C9F8C)),
                ),
                title: const Text('논문 검색'),
                subtitle: const Text('제목이나 저자로 검색'),
                onTap: () {
                  Navigator.pop(context);
                  // 논문 검색 페이지로 이동
                },
              ),
              const SizedBox(height: 10),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE6F3F0),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.qr_code_scanner,
                      color: Color(0xFF4C9F8C)),
                ),
                title: const Text('DOI 스캔'),
                subtitle: const Text('DOI 바코드를 스캔하여 추가'),
                onTap: () {
                  Navigator.pop(context);
                  // 바코드 스캐너 실행
                },
              ),
              const SizedBox(height: 10),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE6F3F0),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.edit_note, color: Color(0xFF4C9F8C)),
                ),
                title: const Text('직접 입력'),
                subtitle: const Text('논문 정보를 수동으로 입력'),
                onTap: () {
                  Navigator.pop(context);
                  // 논문 정보 입력 페이지로 이동
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              '취소',
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }

  // 활동 있는 날 클릭 시 다이얼로그
  void _showDayActivitiesDialog(int day) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${_focusedDay.year}년 ${_focusedDay.month}월 $day일의 활동',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 3,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE6F3F0),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.menu_book,
                      color: Color(0xFF4C9F8C),
                      size: 20,
                    ),
                  ),
                  title: Text(
                    '논문 ${index + 1} 읽음',
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  subtitle: Text(
                    '별점 ${index + 3}/5',
                    style: TextStyle(
                      color: Colors.grey[700],
                    ),
                  ),
                  trailing: Text(
                    '${10 + index}:00',
                    style: TextStyle(
                      color: Colors.grey[600],
                    ),
                  ),
                  onTap: () {
                    // 해당 논문 상세 페이지로 이동
                  },
                );
              },
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4C9F8C),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                child: const Text('닫기'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 검색 화면
class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('검색'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 검색 입력 필드
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: '논문, 저자, 학술지 검색',
                prefixIcon: const Icon(Icons.search, color: Color(0xFF4C9F8C)),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear, color: Colors.grey),
                  onPressed: () {
                    _searchController.clear();
                  },
                ),
                filled: true,
                fillColor: Colors.grey[100],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
            const SizedBox(height: 24),

            // 최근 검색어 섹션
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      '최근 검색어',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text(
                        '모두 지우기',
                        style: TextStyle(
                          color: Color(0xFF4C9F8C),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _buildSearchChip('사회 네트워크'),
                    _buildSearchChip('문화 사회학'),
                    _buildSearchChip('Pierre Bourdieu'),
                    _buildSearchChip('집단행동 이론'),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),

            // 추천 검색어 섹션
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '추천 검색어',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _buildSearchChip('사회심리학', isRecommended: true),
                    _buildSearchChip('집단 정체성', isRecommended: true),
                    _buildSearchChip('미디어 사회학', isRecommended: true),
                    _buildSearchChip('세대 연구', isRecommended: true),
                    _buildSearchChip('질적 연구', isRecommended: true),
                    _buildSearchChip('담론 분석', isRecommended: true),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // 검색 칩 위젯
  Widget _buildSearchChip(String label, {bool isRecommended = false}) {
    return InkWell(
      onTap: () {
        _searchController.text = label;
        // 검색 실행
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isRecommended ? const Color(0xFFE6F3F0) : Colors.grey[200],
          borderRadius: BorderRadius.circular(20),
          border: isRecommended
              ? Border.all(color: const Color(0xFF4C9F8C), width: 1)
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isRecommended)
              Row(
                children: [
                  const Icon(
                    Icons.recommend,
                    size: 14,
                    color: Color(0xFF4C9F8C),
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: isRecommended ? const Color(0xFF4C9F8C) : Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 찜 화면
class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('찜 목록'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {
              // 필터링 옵션 표시
            },
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 10,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: InkWell(
              onTap: () {
                // 논문 상세 페이지로 이동
              },
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 50,
                          height: 70,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE6F3F0),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.article,
                              size: 30,
                              color: Color(0xFF4C9F8C),
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '사회적 연결망과 사회적 자본에 관한 연구 ${index + 1}',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '저자 이름 ${index + 1}, 공동저자',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[700],
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '한국사회학회지, 2023년',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(
                              Icons.star,
                              color: Colors.amber,
                              size: 18,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${(index % 5) + 1}/5',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Icon(
                              Icons.comment_outlined,
                              color: Colors.grey[600],
                              size: 18,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '$index',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        PopupMenuButton(
                          icon: const Icon(Icons.more_vert),
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 1,
                              child: Text('컬렉션에 추가'),
                            ),
                            const PopupMenuItem(
                              value: 2,
                              child: Text('찜 해제'),
                            ),
                            const PopupMenuItem(
                              value: 3,
                              child: Text('공유'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 컬렉션 생성 또는 논문 추가 기능
        },
        backgroundColor: const Color(0xFF4C9F8C),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}

// 소식 화면
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('소식'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(0),
        itemCount: 15,
        itemBuilder: (context, index) {
          // 날짜 구분선 추가
          if (index == 0) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16, top: 16, bottom: 8),
                  child: Text(
                    '오늘',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[800],
                    ),
                  ),
                ),
                _buildActivityItem(index),
              ],
            );
          } else if (index == 5) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16, top: 16, bottom: 8),
                  child: Text(
                    '어제',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[800],
                    ),
                  ),
                ),
                _buildActivityItem(index),
              ],
            );
          } else if (index == 10) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16, top: 16, bottom: 8),
                  child: Text(
                    '이번 주',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[800],
                    ),
                  ),
                ),
                _buildActivityItem(index),
              ],
            );
          }

          return _buildActivityItem(index);
        },
      ),
    );
  }

  // 활동 아이템 위젯
  Widget _buildActivityItem(int index) {
    // 활동 종류 (0: 좋아요, 1: 코멘트, 2: 팔로우, 3: 논문 추가)
    final activityType = index % 4;

    IconData leadingIcon;
    String title;
    Color iconColor;

    switch (activityType) {
      case 0:
        leadingIcon = Icons.thumb_up;
        title = '친구 ${index + 1}님이 당신의 코멘트를 좋아합니다';
        iconColor = Colors.blue;
        break;
      case 1:
        leadingIcon = Icons.comment;
        title = '친구 ${index + 1}님이 당신의 논문에 코멘트를 남겼습니다';
        iconColor = Colors.green;
        break;
      case 2:
        leadingIcon = Icons.person_add;
        title = '친구 ${index + 1}님이 당신을 팔로우합니다';
        iconColor = Colors.purple;
        break;
      case 3:
        leadingIcon = Icons.article;
        title = '친구 ${index + 1}님이 새 논문을 추가했습니다';
        iconColor = const Color(0xFF4C9F8C);
        break;
      default:
        leadingIcon = Icons.notifications;
        title = '알림';
        iconColor = Colors.grey;
    }

    return ListTile(
      leading: CircleAvatar(
        backgroundColor: iconColor.withOpacity(0.2),
        child: Icon(
          leadingIcon,
          color: iconColor,
          size: 20,
        ),
      ),
      title: Text(title),
      subtitle: Text(
        '${index < 3 ? '방금 전' : index < 5 ? '${index}시간 전' : index < 10 ? '어제' : '${index - 9}일 전'}',
        style: TextStyle(
          fontSize: 12,
          color: Colors.grey[600],
        ),
      ),
      onTap: () {
        // 활동 상세 페이지로 이동 또는 관련 항목으로 이동
      },
    );
  }
}

// 프로필 화면 (나의 SOC)
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('나의 SOC'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 취향 분석 섹션
            _buildAnalysisSection(),

            // 좋아한 연구자 섹션
            _buildResearchersSection(),

            // 좋아한 컬렉션 섹션
            _buildCollectionsSection(),

            // 좋아한 코멘트 섹션
            _buildCommentsSection(),
          ],
        ),
      ),
    );
  }

  // 취향 분석 섹션
  Widget _buildAnalysisSection() {
    return SingleChildScrollView(
      child: Container(
        color: Colors.white,
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '취향 분석',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFE9ECF6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                '별점 분포',
                style: TextStyle(
                  color: Color(0xFF3F51B5),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '평가에 있어 주관이 뚜렷한 \'소나무파\'',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            // 별점 분포 그래프
            SizedBox(
              height: 150,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(10, (index) {
                  // 별점 분포 (0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0)
                  final double starValue = (index + 1) * 0.5;
                  final double height = index == 6
                      ? 1.0
                      : // 3.5점이 가장 높게
                      (index >= 5 && index <= 7)
                          ? 0.8
                          : // 3.0, 4.0점도 꽤 높게
                          (index >= 4 && index <= 8)
                              ? 0.5
                              : // 2.5, 4.5점도 중간 정도로
                              0.2; // 나머지는 낮게

                  return Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          index == 6 ? '3.5' : '',
                          style: const TextStyle(
                            color: Color(0xFFFF4081),
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          width: 20,
                          height: 100 * height,
                          decoration: BoxDecoration(
                            color: index == 6
                                ? const Color(0xFFFF4081)
                                : const Color(0xFFFFC1E3),
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          index == 0
                              ? '0.5'
                              : index == 9
                                  ? '5'
                                  : '',
                          style: TextStyle(
                            color: Colors.grey[500],
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                child: Text(
                  '모든 분석 보기',
                  style: TextStyle(
                    color: Color(0xFF4C9F8C),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 좋아한 연구자 섹션
  Widget _buildResearchersSection() {
    final List<Map<String, dynamic>> researchers = [
      {
        'name': '김민석 교수',
        'field': '사회심리학',
        'image': 'https://randomuser.me/api/portraits/men/32.jpg',
      },
      {
        'name': '이지원 교수',
        'field': '집단행동이론',
        'image': 'https://randomuser.me/api/portraits/men/45.jpg',
      },
      {
        'name': '박현우 교수',
        'field': '사회네트워크분석',
        'image': 'https://randomuser.me/api/portraits/men/67.jpg',
      }
    ];

    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '좋아요',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '항목별로 보기 >',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '좋아한 연구자',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '3',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 150,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              shrinkWrap: true,
              itemCount: researchers.length,
              itemBuilder: (context, index) {
                final researcher = researchers[index];
                return Container(
                  width: 80,
                  margin: const EdgeInsets.only(right: 16),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: const Color(0xFFE6F3F0),
                        child: Text(
                          researcher['name'].substring(0, 1),
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF4C9F8C),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        researcher['name'],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        '관심',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // 좋아한 컬렉션 섹션
  Widget _buildCollectionsSection() {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '좋아한 컬렉션',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '1',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: () {},
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6F3F0),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.collections_bookmark,
                          color: Color(0xFF4C9F8C),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '기억해야 할 에너지로 가득한 작품들',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              '특이한 에너지로 가득한 작품 모음',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      for (int i = 0; i < 4; i++)
                        Expanded(
                          child: Container(
                            height: 60,
                            margin: EdgeInsets.only(
                              right: i < 3 ? 4 : 0,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE6F3F0),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Center(
                              child: Icon(
                                Icons.article,
                                color: Color(0xFF4C9F8C),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 좋아한 코멘트 섹션
  Widget _buildCommentsSection() {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '좋아한 코멘트',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '6',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 3,
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: const Color(0xFFE6F3F0),
                          child: Text(
                            '유',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF4C9F8C),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          '유저 6',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '3일 전',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      '정말 흥미로운 관점을 제시한 논문입니다. 특히 사회적 네트워크가 개인의 정체성 형성에 미치는 영향에 관한 부분이 인상적이었습니다.',
                      style: TextStyle(
                        fontSize: 14,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        const Icon(
                          Icons.favorite,
                          color: Colors.red,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '12',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(width: 16),
                        const Icon(
                          Icons.comment_outlined,
                          color: Colors.grey,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '3',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '사회 네트워크 분석과 개인 정체성',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Text(
                '더 보기',
                style: TextStyle(
                  color: Color(0xFF4C9F8C),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
