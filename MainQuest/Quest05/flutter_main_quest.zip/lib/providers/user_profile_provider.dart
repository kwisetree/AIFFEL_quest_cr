import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:typed_data';

class UserProfileProvider with ChangeNotifier {
  String _name = '사용자 이름';
  String _field = '연구 분야';
  String _university = '대학교';
  Uint8List? _imageFile;

  String get name => _name;
  String get field => _field;
  String get university => _university;
  Uint8List? get imageFile => _imageFile;

  UserProfileProvider() {
    loadProfileData();
  }

  Future<void> loadProfileData() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      _name = prefs.getString('userName') ?? '사용자 이름';
      _field = prefs.getString('userField') ?? '사회심리학';
      _university = prefs.getString('userUniversity') ?? '와플대학교';

      String? savedImage = prefs.getString('userProfileImage');
      if (savedImage != null && savedImage.isNotEmpty) {
        try {
          _imageFile = base64Decode(savedImage);
        } catch (e) {
          print('Image decode error: $e');
          _imageFile = null;
        }
      }

      notifyListeners();
    } catch (e) {
      print('Error loading profile data: $e');
    }
  }

  Future<void> updateProfile({
    required String name,
    required String field,
    required String university,
    Uint8List? imageFile,
  }) async {
    try {
      _name = name;
      _field = field;
      _university = university;
      if (imageFile != null) {
        _imageFile = imageFile;
      }

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('userName', _name);
      await prefs.setString('userField', _field);
      await prefs.setString('userUniversity', _university);

      if (_imageFile != null) {
        String base64Image = base64Encode(_imageFile!);
        await prefs.setString('userProfileImage', base64Image);
      }

      print('Profile data updated successfully');
      notifyListeners();
    } catch (e) {
      print('Error updating profile: $e');
    }
  }
}
