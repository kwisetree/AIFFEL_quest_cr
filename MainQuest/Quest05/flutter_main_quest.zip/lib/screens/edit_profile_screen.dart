import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:ui' as ui;
import 'dart:convert';
import 'dart:typed_data';
import 'package:image_picker_web/image_picker_web.dart';
import 'package:provider/provider.dart';
import '../providers/user_profile_provider.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _fieldController = TextEditingController();
  final TextEditingController _universityController = TextEditingController();

  Uint8List? _imageFile;
  bool _isLoading = false;
  bool _isCameraActive = false;
  late String _viewId;

  @override
  void initState() {
    super.initState();
    _loadProfileData();
    _viewId = 'camera-${DateTime.now().millisecondsSinceEpoch}';
    // 웹 요소 등록
    ui.platformViewRegistry.registerViewFactory(_viewId, (int viewId) {
      return html.VideoElement()
        ..style.width = '100%'
        ..style.height = '100%'
        ..style.objectFit = 'cover'
        ..autoplay = true;
    });
  }

  // 프로필 데이터 불러오기
  _loadProfileData() {
    final userProfile =
        Provider.of<UserProfileProvider>(context, listen: false);

    setState(() {
      _nameController.text = userProfile.name;
      _fieldController.text = userProfile.field;
      _universityController.text = userProfile.university;
      _imageFile = userProfile.imageFile;
    });
  }

  // 카메라 시작
  void _startCamera() async {
    setState(() {
      _isCameraActive = true;
    });

    // 잠시 대기하여 UI가 업데이트될 시간을 줍니다
    await Future.delayed(const Duration(milliseconds: 500));

    try {
      final videoElement =
          html.document.getElementById(_viewId) as html.VideoElement;

      // 카메라 접근 요청
      final mediaStream =
          await html.window.navigator.mediaDevices?.getUserMedia({
        'video': {
          'facingMode': 'user',
        },
        'audio': false
      });

      videoElement.srcObject = mediaStream;
    } catch (e) {
      print('카메라 접근 오류: $e');
      setState(() {
        _isCameraActive = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('카메라에 접근할 수 없습니다: $e')),
      );
    }
  }

  // 사진 촬영
  void _takePicture() {
    try {
      final videoElement =
          html.document.getElementById(_viewId) as html.VideoElement;

      // 캔버스에 비디오 프레임 캡처
      final canvasElement = html.CanvasElement(
        width: videoElement.videoWidth,
        height: videoElement.videoHeight,
      );

      canvasElement.context2D.drawImage(videoElement, 0, 0);
      final dataUrl = canvasElement.toDataUrl('image/png');

      // 데이터 URL에서 base64 데이터 추출
      final base64Data = dataUrl.split(',')[1];
      final imageData = base64Decode(base64Data);

      setState(() {
        _imageFile = Uint8List.fromList(imageData);
        _isCameraActive = false;
      });

      // 비디오 스트림 중지
      final tracks = videoElement.srcObject?.getTracks();
      tracks?.forEach((track) => track.stop());
    } catch (e) {
      print('사진 촬영 오류: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('사진 촬영 중 오류가 발생했습니다: $e')),
      );
    }
  }

  // 카메라 중지
  void _stopCamera() {
    try {
      final videoElement =
          html.document.getElementById(_viewId) as html.VideoElement;
      final tracks = videoElement.srcObject?.getTracks();
      tracks?.forEach((track) => track.stop());

      setState(() {
        _isCameraActive = false;
      });
    } catch (e) {
      print('카메라 중지 오류: $e');
    }
  }

  // 갤러리에서 이미지 선택
  Future<void> _pickImageFromGallery() async {
    try {
      final pickedFile = await ImagePickerWeb.getImageAsBytes();

      if (pickedFile != null) {
        setState(() {
          _imageFile = pickedFile;
        });
      }
    } catch (e) {
      print('이미지 선택 중 오류: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('이미지 선택 중 오류가 발생했습니다: $e')),
      );
    }
  }

  // 이미지 선택 다이얼로그
  void _showImageSourceDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('프로필 사진'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                GestureDetector(
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Row(
                      children: [
                        Icon(Icons.camera_alt, color: Color(0xFF4C9F8C)),
                        SizedBox(width: 10),
                        Text('카메라로 촬영하기'),
                      ],
                    ),
                  ),
                  onTap: () {
                    Navigator.of(context).pop();
                    _startCamera();
                  },
                ),
                const Divider(),
                GestureDetector(
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Row(
                      children: [
                        Icon(Icons.photo_library, color: Color(0xFF4C9F8C)),
                        SizedBox(width: 10),
                        Text('갤러리에서 선택하기'),
                      ],
                    ),
                  ),
                  onTap: () {
                    Navigator.of(context).pop();
                    _pickImageFromGallery();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // 프로필 데이터 저장
  _saveProfileData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final userProfile =
          Provider.of<UserProfileProvider>(context, listen: false);
      await userProfile.updateProfile(
        name: _nameController.text,
        field: _fieldController.text,
        university: _universityController.text,
        imageFile: _imageFile,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('프로필이 성공적으로 저장되었습니다.')),
      );

      Navigator.pop(context, true);
    } catch (e) {
      print('프로필 저장 중 오류: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('프로필 저장 중 오류가 발생했습니다: $e')),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('프로필 수정'),
        actions: [
          if (_isLoading)
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2.0,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              ),
            )
          else
            IconButton(
              icon: const Icon(Icons.save),
              onPressed: _saveProfileData,
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // 카메라 활성화 상태일 때 웹캠 UI 표시
            if (_isCameraActive)
              Column(
                children: [
                  Container(
                    width: 300,
                    height: 300,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border:
                          Border.all(color: const Color(0xFF4C9F8C), width: 2),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: HtmlElementView(
                      viewType: _viewId,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton.icon(
                        icon: const Icon(Icons.camera_alt),
                        label: const Text('사진 촬영'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF4C9F8C),
                        ),
                        onPressed: _takePicture,
                      ),
                      const SizedBox(width: 16),
                      OutlinedButton.icon(
                        icon: const Icon(Icons.close),
                        label: const Text('취소'),
                        onPressed: _stopCamera,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ],
              )
            else
              // 프로필 이미지 선택
              GestureDetector(
                onTap: _showImageSourceDialog,
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 60,
                      backgroundColor: const Color(0xFFE6F3F0),
                      backgroundImage:
                          _imageFile != null ? MemoryImage(_imageFile!) : null,
                      child: _imageFile == null
                          ? const Icon(Icons.camera_alt,
                              size: 40, color: Color(0xFF4C9F8C))
                          : null,
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFF4C9F8C),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.all(4.0),
                          child: Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            const SizedBox(height: 24),

            // 이름 입력 필드
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: '이름',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: const Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 16),

            // 연구 분야 입력 필드
            TextField(
              controller: _fieldController,
              decoration: InputDecoration(
                labelText: '연구 분야',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: const Icon(Icons.school),
              ),
            ),
            const SizedBox(height: 16),

            // 대학 입력 필드
            TextField(
              controller: _universityController,
              decoration: InputDecoration(
                labelText: '소속 대학',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: const Icon(Icons.location_on),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _fieldController.dispose();
    _universityController.dispose();

    // 카메라 리소스 해제
    if (_isCameraActive) {
      _stopCamera();
    }

    super.dispose();
  }
}
