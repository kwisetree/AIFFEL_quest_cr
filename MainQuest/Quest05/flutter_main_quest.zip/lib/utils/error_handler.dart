import 'dart:io';
import 'package:dio/dio.dart';

class AppException implements Exception {
  final String message;
  final String? code;
  final StackTrace? stackTrace;

  AppException(this.message, {this.code, this.stackTrace});

  @override
  String toString() =>
      'AppException: $message${code != null ? ' (Code: $code)' : ''}';
}

class NetworkException extends AppException {
  NetworkException(String message, {String? code, StackTrace? stackTrace})
      : super(message, code: code, stackTrace: stackTrace);
}

class AuthException extends AppException {
  AuthException(String message, {String? code, StackTrace? stackTrace})
      : super(message, code: code, stackTrace: stackTrace);
}

class ServerException extends AppException {
  ServerException(String message, {String? code, StackTrace? stackTrace})
      : super(message, code: code, stackTrace: stackTrace);
}

class NotFoundException extends AppException {
  NotFoundException(String message, {String? code, StackTrace? stackTrace})
      : super(message, code: code, stackTrace: stackTrace);
}

class ValidationException extends AppException {
  final Map<String, List<String>>? errors;

  ValidationException(String message,
      {this.errors, String? code, StackTrace? stackTrace})
      : super(message, code: code, stackTrace: stackTrace);
}

class ErrorHandler {
  // HTTP 상태 코드 기반 오류 처리
  static AppException handleHttpError(int? statusCode) {
    switch (statusCode) {
      case 400:
        return ValidationException('잘못된 요청입니다. 입력값을 확인해주세요.',
            code: 'BAD_REQUEST');
      case 401:
        return AuthException('인증이 필요합니다. 다시 로그인해주세요.', code: 'UNAUTHORIZED');
      case 403:
        return AuthException('접근 권한이 없습니다.', code: 'FORBIDDEN');
      case 404:
        return NotFoundException('요청한 리소스를 찾을 수 없습니다.', code: 'NOT_FOUND');
      case 422:
        return ValidationException('입력 데이터가 유효하지 않습니다.',
            code: 'VALIDATION_ERROR');
      case 500:
      case 501:
      case 502:
      case 503:
        return ServerException('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.',
            code: 'SERVER_ERROR');
      default:
        return AppException('오류가 발생했습니다. (상태 코드: $statusCode)',
            code: 'UNKNOWN_ERROR');
    }
  }

  // Dio 예외 처리
  static AppException handleDioError(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return NetworkException('네트워크 연결 시간이 초과되었습니다. 인터넷 연결을 확인해주세요.',
            code: 'TIMEOUT_ERROR');
      case DioExceptionType.badResponse:
        return handleHttpError(error.response?.statusCode);
      case DioExceptionType.cancel:
        return AppException('요청이 취소되었습니다.', code: 'REQUEST_CANCELLED');
      case DioExceptionType.connectionError:
        return NetworkException('네트워크 연결에 문제가 발생했습니다. 인터넷 연결을 확인해주세요.',
            code: 'CONNECTION_ERROR');
      default:
        return AppException('오류가 발생했습니다: ${error.message}', code: 'DIO_ERROR');
    }
  }

  // 기타 예외 처리
  static AppException handleUnknownError(dynamic error) {
    if (error is SocketException) {
      return NetworkException('네트워크 연결에 문제가 발생했습니다. 인터넷 연결을 확인해주세요.',
          code: 'SOCKET_ERROR');
    } else if (error is HttpException) {
      return NetworkException('HTTP 요청 중 오류가 발생했습니다.', code: 'HTTP_ERROR');
    } else if (error is FormatException) {
      return AppException('데이터 형식 오류가 발생했습니다.', code: 'FORMAT_ERROR');
    } else {
      return AppException('오류가 발생했습니다: ${error.toString()}',
          code: 'UNKNOWN_ERROR');
    }
  }

  // 사용자 친화적 에러 메시지 반환
  static String getUserFriendlyMessage(AppException exception) {
    if (exception is NetworkException) {
      return '네트워크 연결을 확인해주세요. 인터넷이 연결되어 있지 않거나 서버에 접속할 수 없습니다.';
    } else if (exception is AuthException) {
      return '로그인이 필요하거나 세션이 만료되었습니다. 다시 로그인해주세요.';
    } else if (exception is ValidationException) {
      return '입력한 정보가 올바르지 않습니다. 다시 확인해주세요.';
    } else if (exception is ServerException) {
      return '서버에 일시적인 문제가 발생했습니다. 잠시 후 다시 시도해주세요.';
    } else if (exception is NotFoundException) {
      return '요청하신 정보를 찾을 수 없습니다.';
    } else {
      return exception.message;
    }
  }
}
