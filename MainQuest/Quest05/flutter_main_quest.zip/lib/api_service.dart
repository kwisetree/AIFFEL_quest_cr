import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:retry/retry.dart';
import '../models/paper.dart';
import '../models/user.dart';
import '../utils/error_handler.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  final Dio _dio = Dio();
  final String _baseUrl = 'https://api.socioscholarly.com/v1'; // 예시 URL
  String? _authToken;

  // 싱글톤 패턴
  factory ApiService() {
    return _instance;
  }

  ApiService._internal() {
    _dio.options.baseUrl = _baseUrl;
    _dio.options.connectTimeout = const Duration(seconds: 10);
    _dio.options.receiveTimeout = const Duration(seconds: 10);
    
    // 인터셉터 추가 - 모든 요청에 토큰 추가, 오류 처리
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          if (_authToken != null) {
            options.headers['Authorization'] = 'Bearer $_authToken';
          }
          return handler.next(options);
        },
        onError: (DioException error, handler) async {
          // 401 오류(인증 실패)면 토큰 갱신 시도
          if (error.response?.statusCode == 401) {
            if (await _refreshToken()) {
              // 토큰 갱신 성공하면 원래 요청 재시도
              return handler.resolve(await _dio.fetch(error.requestOptions));
            }
          }
          return handler.next(error);
        },
      ),
    );
  }

  // 토큰 설정
  void setAuthToken(String token) {
    _authToken = token;
  }

  // 토큰 갱신
  Future<bool> _refreshToken() async {
    try {
      final response = await _dio.post('/auth/refresh');
      if (response.statusCode == 200) {
        _authToken = response.data['token'];
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // 로그인 API
  Future<User> login(String email, String password) async {
    try {
      final response = await retry(
        () => _dio.post(
          '/auth/login',
          data: {
            'email': email,
            'password': password,
          },
        ),
        retryIf: (e) => e is SocketException || e is TimeoutException,
        maxAttempts: 3,
      );

      if (response.statusCode == 200) {
        _authToken = response.data['token'];
        return User.fromJson(response.data['user']);
      } else {
        throw ErrorHandler.handleHttpError(response.statusCode);
      }
    } on DioException catch (e) {
      throw ErrorHandler.handleDioError(e);
    } catch (e) {
      throw ErrorHandler.handleUnknownError(e);
    }
  }

  // 논문 검색 API
  Future<List<Paper>> searchPapers(String query, {int page = 1, int limit = 20}) async {
    try {
      final response = await _dio.get(
        '/papers/search',
        queryParameters: {
          'q': query,
          'page': page,
          'limit': limit,
        },
      );

      if (response.statusCode == 200) {
        final List<dynamic> results = response.data['results'];
        return results.map((json) => Paper.fromJson(json)).toList();
      } else {
        throw ErrorHandler.handleHttpError(response.statusCode);
      }
    } on DioException catch (e) {
      throw ErrorHandler.handleDioError(e);
    } catch (e) {
      throw ErrorHandler.handleUnknownError(e);
    }
  }

  // 논문 상세 정보 가져오기
  Future<Paper> getPaperDetails(String paperId) async {
    try {
      final response = await _dio.get('/papers/$paperId');

      if (response.statusCode == 200) {
        return Paper.fromJson(response.data);
      } else {
        throw ErrorHandler.handleHttpError(response.statusCode);
      }
    } on DioException catch (e) {
      throw ErrorHandler.handleDioError(e);
    } catch (e) {
      throw ErrorHandler.handleUnknownError(e);
    }
  }

  // 논문 컬렉션에 추가
  Future<void> addToCollection(String paperId, String collectionId) async {
    try {
      final response = await _dio.post(
        '/collections/$collectionId/papers',
        data: {
          'paperId': paperId,
        },
      );

      if (response.statusCode != 200 && response.statusCode != 201) {
        throw ErrorHandler.handleHttpError(response.statusCode);
      }
    } on DioException catch (e) {
      throw ErrorHandler.handleDioError(e);
    } catch (e) {
      throw ErrorHandler.handleUnknownError(e);
    }
  }

  // 논문에 평가 추가
  Future<void> ratePaper(String paperId, double rating, String comment) async {
    try {
      final response = await _dio.post(
        '/papers/$paperId/ratings',
        data: {
          'rating': rating,
          'comment': comment,
        },
      );

      if (response.statusCode != 200 && response.statusCode != 201) {
        throw ErrorHandler.handleHttpError(response.statusCode);
      }
    } on DioException catch (e) {
      throw ErrorHandler.handleDioError(e);
    } catch (e) {
      throw ErrorHandler.handleUnknownError(e);
    }
  }

  // 사용자 프로필 업데이트
  Future<User> updateUserProfile(Map<String, dynamic> profileData) async {
    try {
      final response = await _dio.patch(
        '/users/profile',
        data: profileData,
      );

      if (response.statusCode == 200) {
        return User.fromJson(response.data);
      } else {
        throw ErrorHandler.handleHttpError(response.statusCode);
      }
    } on DioException catch (e) {
      throw ErrorHandler.handleDioError(e);
    } catch (e) {
      throw ErrorHandler.handleUnknownError(e);
    }
  }

  // LLM 서비스 API 호출 (논문 추천 기능)
  Future<List<Paper>> getAiRecommendations(List<String> interests, List<String> recentlyViewed) async {
    try {
      final response = await _dio.post(
        '/ai/recommendations',
        data: {
          'interests': interests,
          'recentlyViewed': recentlyViewed,
        },
      );

      if (response.statusCode == 200) {
        final List<dynamic> results = response.data['recommendations'];
        return results.map((json) => Paper.fromJson(json)).toList();
      } else {
        throw ErrorHandler.handleHttpError(response.statusCode);
      }
    } on DioException catch (e) {
      throw ErrorHandler.handleDioError(e);
    } catch (e) {
      throw ErrorHandler.handleUnknownError(e);
    }
  }
}