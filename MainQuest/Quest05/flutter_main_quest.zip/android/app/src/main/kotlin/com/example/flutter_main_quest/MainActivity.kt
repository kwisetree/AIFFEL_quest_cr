package com.example.flutter_main_quest

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
